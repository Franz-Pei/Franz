package com.dxfx.netty.constant;

public class Constants {
	// 修复：确保路径格式正确
	public static final String Server_PATH = "/netty";
	}