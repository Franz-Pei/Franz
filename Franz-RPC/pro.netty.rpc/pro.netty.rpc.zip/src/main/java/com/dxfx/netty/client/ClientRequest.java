package com.dxfx.netty.client;

import java.util.concurrent.atomic.AtomicLong;

public class ClientRequest {

    private final long id;
    private Object content;
    private String command;  // 添加command字段
    private final AtomicLong aid = new AtomicLong(1);
    
    public ClientRequest() {
        id = aid.incrementAndGet();
    }

    public long getId() {
        return id;
    }

    public Object getContent() {
        return content;
    }
    
    public void setContent(Object content) {
        this.content = content;
    }

    // 修正：正确实现setCommand方法
    public void setCommand(String command) {
        this.command = command;
    }
    
    // 添加：getCommand方法
    public String getCommand() {
        return command;
    }
}