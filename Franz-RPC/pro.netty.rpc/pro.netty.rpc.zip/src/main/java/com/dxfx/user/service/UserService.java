package com.dxfx.user.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.dxfx.user.bean.User;

@Service
public class UserService {

	public void save(User user) {
		// TODO Auto-generated method stub
		
	}

	public void saveList(List<User> users) {
		// TODO Auto-generated method stub
		
	}

}
