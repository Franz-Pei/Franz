package com.dxfx.netty.util;

public class Response {

	private Long id;
	private Object result;
	private String status;//000表示成功,其他表示失败
	private String meg;//失败的原因
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Object getResult() {
		return result;
	}
	public void setResult(Object result) {
		this.result = result;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMeg() {
		return meg;
	}
	public void setMeg(String meg) {
		this.meg = meg;
	}
	public void setCode(String code) {
		// TODO Auto-generated method stub
		
	}
	
	
}
